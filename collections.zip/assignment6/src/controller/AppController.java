package controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import entity.Building;
import entity.Room;
import entity.User;

public class AppController {

	public static void main(String args[]) {

		Map<Building, Map<Room, Set<User>>> map = new HashMap<>();
		Map<Room, Set<User>> map1 = new HashMap<>();
		Map<Room, Set<User>> map2 = new HashMap<>();
		Set<User> users = new TreeSet<>();
		Set<User> users1 = new TreeSet<>();
		Set<User> users2 = new TreeSet<>();
		Set<User> users3 = new TreeSet<>();
		users.add(new User(1, "Juhi", "7205367013"));
		users.add(new User(2, "Neha", "7209577305"));
		
		users1.add(new User(3, "Pragati", "6478392992"));
		users1.add(new User(4, "Abhishek", "7463829208"));
		
		users2.add(new User(3, "Maya", "45367382923"));
		users2.add(new User(4, "Sudip", "657849393002"));
		
		users3.add(new User(3, "Ram", "65748839922"));
		users3.add(new User(4, "Komal", "6478393932"));
		
		map1.put(new Room(1, "Mahua"), users);
		map1.put(new Room(2, "Amla"), users1);
		
		map2.put(new Room(3,"Dimri"),users2 );
		map2.put(new Room(4,"Chandan"),users3);
		
		map.put(new Building(1, "GLC"), map1);
		map.put(new Building(2, "SDB"), map2);
		
		map.entrySet().forEach(i->{
			System.out.println(i.getKey().getBuildingName());
			i.getValue().entrySet().forEach(j->{
				System.out.println(j.getKey().getRoomName());
				j.getValue().forEach(k->{
					System.out.println(k.getUserName()+":"+k.getPhoneNo());
				});
			});
		});

	}
}
