package entity;

public class User implements Comparable<User> {

	private int userId;

	private String userName;

	private String phoneNo;

	public User() {
		super();
	}

	public User(int userId, String userName, String phoneNo) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.phoneNo = phoneNo;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", phoneNo=" + phoneNo + "]";
	}

	@Override
	public int compareTo(User user) {

		return user.getUserName().compareTo(this.userName);
	}

}
