package entity;

public class Building implements Comparable<Building>{

	private int buildingId;

	private String buildingName;

	public Building() {
		super();
	}

	public Building(int buildingId, String buildingName) {
		super();
		this.buildingId = buildingId;
		this.buildingName = buildingName;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	

	@Override
	public String toString() {
		return "Building [buildingId=" + buildingId + ", buildingName=" + buildingName + "]";
	}

	@Override
	public int compareTo(Building building) {
		
		return (building.getBuildingName().compareTo(this.buildingName));
	}


}
